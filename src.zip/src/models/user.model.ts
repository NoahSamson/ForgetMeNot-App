export interface User{
    email: string;
    password: string;
    userName: string;
    firstName: string;
    lastName: string;
    address: string;
    phoneNum: string;
    caretaker: string;
    type: string;
}